package com.example.cleanbrowser.browser

import android.media.MediaMetadataRetriever
import android.webkit.CookieManager
import com.example.cleanbrowser.download.Hls
import com.example.cleanbrowser.download.Http
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.IOException
import java.io.InputStream
import kotlin.math.min

/** One downloadable choice: a resolution of an MP4 file, or one quality of an HLS stream. */
data class VideoOption(
    val label: String,            // "480p (854x480)"
    val url: String,              // the file, or the chosen variant playlist
    val isHls: Boolean,
    val height: Int,              // shorter side in pixels, 0 if unknown
    val sizeBytes: Long?,
    val estimated: Boolean,       // HLS size is estimated from bitrate x length
    val seconds: Double?,
    val hasAudio: Boolean?,       // null = unknown
    val audioUrl: String? = null, // separate HLS audio playlist (merged when saving)
    val usable: Boolean = true,   // false: live / encrypted / audio-only
) {
    /** "≈ 45.23 MB · 12 min 34 sec · With audio" */
    val detail: String?
        get() = listOfNotNull(
            sizeBytes?.let { (if (estimated) "≈ " else "") + Fmt.size(it) },
            seconds?.let { Fmt.duration(it) },
            when (hasAudio) { true -> "With audio"; false -> "No audio"; null -> null },
        ).joinToString(" · ").ifEmpty { null }

    /** Hover previews and thumbnail clips: very short or tiny. */
    val isSmall: Boolean
        get() = (seconds != null && seconds < MIN_SECONDS) ||
            (!estimated && sizeBytes != null && sizeBytes < MIN_BYTES)

    companion object {
        const val MIN_SECONDS = 15.0
        const val MIN_BYTES = 1_000_000L
    }
}

/** Reads resolution, size, length and audio of a video link without downloading it. */
object VideoProbe {

    suspend fun probe(video: DetectedVideo, ua: String, referer: String): List<VideoOption> {
        val found = withTimeoutOrNull(15_000) {
            withContext(Dispatchers.IO) {
                runCatching { if (video.isHls) hls(video, ua, referer) else listOf(mp4(video, ua, referer)) }.getOrNull()
            }
        }
        return found?.takeIf { it.isNotEmpty() }
            ?: listOf(VideoOption("Original quality", video.url, video.isHls, 0, null, false, null, null))
    }

    // ===================== HLS =====================

    private fun hls(video: DetectedVideo, ua: String, referer: String): List<VideoOption> {
        val text = Http.text(video.url, ua, referer)

        if (!Hls.isMaster(text)) {
            val m = Hls.parseMedia(text, video.url)
            return listOf(VideoOption("Original quality", video.url, true, 0, null, false, m.seconds, null, null, m.usable))
        }

        val master = Hls.parseMaster(text, video.url)
        val variants = master.variants
            .groupBy { it.width to it.height }                       // same resolution -> keep the best bitrate
            .map { (_, g) -> g.maxBy { it.bandwidth } }
            .sortedWith(compareByDescending<Hls.Variant> { min(it.width, it.height) }.thenByDescending { it.bandwidth })
        if (variants.isEmpty()) return emptyList()

        // All qualities share one length: read it (and check the stream is saveable) from the best one.
        val top = runCatching { Hls.parseMedia(Http.text(variants.first().url, ua, referer), variants.first().url) }.getOrNull()
        val seconds = top?.seconds
        val usable = top?.usable ?: true

        return variants.map { v ->
            val audioUrl = master.audioFor(v)
            val codecs = v.codecs
            val hasAudio = when {
                audioUrl != null -> true
                codecs == null -> null
                else -> listOf("mp4a", "ac-3", "ec-3", "opus").any { codecs.contains(it) }
            }
            val known = v.width > 0 && v.height > 0
            val height = if (known) min(v.width, v.height) else 0
            val label = if (known) "${height}p (${v.width}x${v.height})" else "Quality ${v.bandwidth / 1000} kbps"
            val estimate = if (seconds != null && v.bandwidth > 0) (v.bandwidth / 8.0 * seconds).toLong() else null
            VideoOption(label, v.url, true, height, estimate, true, seconds, hasAudio, audioUrl, usable)
        }
    }

    // ===================== MP4 =====================

    private class Mp4Header(
        val width: Int, val height: Int, val seconds: Double?, val hasVideo: Boolean, val hasAudio: Boolean,
    )

    private fun mp4(video: DetectedVideo, ua: String, referer: String): VideoOption {
        val reader = RangeReader(video.url, ua, referer)
        val header = runCatching { readHeader(reader) }.getOrNull()
        val size = reader.total.takeIf { it > 0 }

        var w = header?.width ?: 0
        var h = header?.height ?: 0
        var seconds = header?.seconds
        var hasAudio: Boolean? = header?.hasAudio
        var hasVideo: Boolean? = header?.hasVideo

        // Header couldn't be read (server without Range, unusual layout): let Android read it.
        if (header == null || seconds == null || (hasVideo == true && w == 0)) {
            runCatching {
                val headers = mutableMapOf("User-Agent" to ua, "Referer" to referer)
                CookieManager.getInstance().getCookie(video.url)?.let { headers["Cookie"] = it }
                MediaMetadataRetriever().use { r ->
                    r.setDataSource(video.url, headers)
                    w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: w
                    h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: h
                    if (seconds == null) {
                        seconds = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                            ?.toLongOrNull()?.takeIf { it > 0 }?.let { it / 1000.0 }
                    }
                    hasAudio = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO) == "yes"
                    hasVideo = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_VIDEO) == "yes"
                }
            }
        }

        val urlHeight = Regex("(\\d{3,4})[pP]").find(video.url)?.groupValues?.get(1)?.toIntOrNull() ?: 0
        val height = if (w > 0 && h > 0) min(w, h) else urlHeight
        val audioOnly = hasVideo == false
        val label = when {
            audioOnly -> "Audio only"
            w > 0 && h > 0 -> "${height}p (${w}x${h})"
            urlHeight > 0 -> "${urlHeight}p"
            else -> "Original quality"
        }
        return VideoOption(label, video.url, false, height, size, false, seconds, hasAudio, null, usable = !audioOnly)
    }

    /** Reads small pieces of the file with HTTP Range requests instead of downloading it. */
    private class RangeReader(private val url: String, private val ua: String, private val referer: String) {
        var total = -1L
            private set
        private var rangeOk = true
        private var first: ByteArray? = null

        private fun fetch(start: Long, length: Int): ByteArray? {
            val c = Http.open(url, ua, referer, rangeStart = start, rangeEnd = start + length - 1, timeout = 8_000)
            try {
                when (val code = c.responseCode) {
                    206 -> c.getHeaderField("Content-Range")?.substringAfter('/')?.toLongOrNull()?.let { total = it }
                    200 -> {
                        rangeOk = false                              // server ignores Range
                        if (start > 0) return null
                        total = c.contentLengthLong
                    }
                    else -> throw IOException("HTTP $code")
                }
                return c.inputStream.readUpTo(length)
            } finally {
                c.disconnect()
            }
        }

        fun first(): ByteArray? {
            first?.let { return it }
            return fetch(0, 262_144)?.also { first = it }
        }

        fun read(offset: Long, len: Int): ByteArray? {
            val f = first() ?: return null
            if (offset + len <= f.size) return f.copyOfRange(offset.toInt(), (offset + len).toInt())
            if (!rangeOk) return null
            return fetch(offset, len)
        }
    }

    private fun InputStream.readUpTo(n: Int): ByteArray {
        val buf = ByteArray(n)
        var off = 0
        while (off < n) {
            val r = read(buf, off, n - off)
            if (r < 0) break
            off += r
        }
        return if (off == n) buf else buf.copyOf(off)
    }

    /** Walks the top-level boxes until it finds 'moov' (at the start or the end of the file). */
    private fun readHeader(r: RangeReader): Mp4Header? {
        var pos = 0L
        for (step in 0 until 24) {
            val hdr = r.read(pos, 16) ?: return null
            if (hdr.size < 8) return null
            var size = u32(hdr, 0)
            val type = String(hdr, 4, 4, Charsets.ISO_8859_1)
            var headerLen = 8
            if (size == 1L) {
                if (hdr.size < 16) return null
                size = u64(hdr, 8)
                headerLen = 16
            } else if (size == 0L) {
                if (r.total <= 0) return null
                size = r.total - pos
            }
            if (size < headerLen) return null
            if (type == "moov") {
                val bodyLen = size - headerLen
                if (bodyLen <= 0 || bodyLen > 8_000_000) return null
                val body = r.read(pos + headerLen, bodyLen.toInt()) ?: return null
                return parseMoov(body)
            }
            pos += size
            if (r.total in 1..pos) return null
        }
        return null
    }

    private fun parseMoov(b: ByteArray): Mp4Header {
        var seconds: Double? = null
        var w = 0
        var h = 0
        var hasVideo = false
        var hasAudio = false

        forEachBox(b, 0, b.size) { type, s, e ->
            when (type) {
                "mvhd" -> if (e - s >= 32) {
                    val version = b[s].toInt()
                    val timescale = if (version == 1) u32(b, s + 20) else u32(b, s + 12)
                    val duration = if (version == 1) u64(b, s + 24) else u32(b, s + 16)
                    if (timescale > 0 && duration > 0) seconds = duration.toDouble() / timescale
                }
                "trak" -> {
                    var tw = 0
                    var th = 0
                    var handler = ""
                    forEachBox(b, s, e) { t2, s2, e2 ->
                        when (t2) {
                            "tkhd" -> {
                                val o = if (b[s2].toInt() == 1) 88 else 76
                                if (s2 + o + 8 <= e2) {
                                    tw = (u32(b, s2 + o) shr 16).toInt()
                                    th = (u32(b, s2 + o + 4) shr 16).toInt()
                                }
                            }
                            "mdia" -> forEachBox(b, s2, e2) { t3, s3, e3 ->
                                if (t3 == "hdlr" && s3 + 12 <= e3) handler = String(b, s3 + 8, 4, Charsets.ISO_8859_1)
                            }
                        }
                    }
                    if (handler == "vide") {
                        hasVideo = true
                        if (w == 0 && tw > 0 && th > 0) { w = tw; h = th }
                    } else if (handler == "soun") {
                        hasAudio = true
                    }
                }
            }
        }
        return Mp4Header(w, h, seconds, hasVideo, hasAudio)
    }

    /** Calls [cb] with (type, payloadStart, boxEnd) for each box between [start] and [end]. */
    private fun forEachBox(b: ByteArray, start: Int, end: Int, cb: (String, Int, Int) -> Unit) {
        var p = start
        while (p + 8 <= end) {
            var size = u32(b, p)
            var headerLen = 8
            val type = String(b, p + 4, 4, Charsets.ISO_8859_1)
            if (size == 1L && p + 16 <= end) { size = u64(b, p + 8); headerLen = 16 }
            else if (size == 0L) size = (end - p).toLong()
            if (size < headerLen || p + size > end) break
            cb(type, p + headerLen, (p + size).toInt())
            p += size.toInt()
        }
    }

    private fun u32(b: ByteArray, o: Int): Long =
        ((b[o].toLong() and 0xFF) shl 24) or ((b[o + 1].toLong() and 0xFF) shl 16) or
            ((b[o + 2].toLong() and 0xFF) shl 8) or (b[o + 3].toLong() and 0xFF)

    private fun u64(b: ByteArray, o: Int): Long = (u32(b, o) shl 32) or u32(b, o + 4)
}
