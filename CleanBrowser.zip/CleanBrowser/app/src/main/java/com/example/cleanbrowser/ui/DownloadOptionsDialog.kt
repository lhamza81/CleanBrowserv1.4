package com.example.cleanbrowser.ui

import android.net.Uri
import android.webkit.WebView
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.cleanbrowser.browser.DetectedVideo
import com.example.cleanbrowser.browser.PageInfo
import com.example.cleanbrowser.browser.PageMetadata
import com.example.cleanbrowser.browser.VideoOption
import com.example.cleanbrowser.browser.VideoProbe
import com.example.cleanbrowser.download.FileNames
import com.example.cleanbrowser.download.ResolutionPrefs
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit

/** The resolution picked last time, or the closest one: same, else the next lower, else the next higher. */
private fun pickPreferred(options: List<VideoOption>, lastHeight: Int): VideoOption? {
    if (options.isEmpty()) return null
    if (lastHeight <= 0) return options.first()                      // best quality first
    options.firstOrNull { it.height == lastHeight }?.let { return it }
    options.filter { it.height in 1 until lastHeight }.maxByOrNull { it.height }?.let { return it }
    return options.filter { it.height > lastHeight }.minByOrNull { it.height } ?: options.first()
}

/**
 * Lists the full videos found on the page (MP4 and HLS) with resolution, size, length and audio.
 * Short preview clips are hidden. Buttons: Cancel | Rename | Download.
 */
@Composable
fun DownloadOptionsDialog(
    videos: List<DetectedVideo>,
    pageUrl: String,
    pageTitle: String,
    userAgent: String,
    webView: WebView?,
    onDismiss: () -> Unit,
    onConfirm: (VideoOption, String) -> Unit,
) {
    val ctx = LocalContext.current
    val snapshot = videos.toList()

    // Name: starts from title + site, then upgrades to "Title - Channel - Site".
    var name by remember {
        val host = Uri.parse(pageUrl).host.orEmpty().removePrefix("www.")
        mutableStateOf(PageMetadata.buildName(PageInfo(pageTitle.ifBlank { "video" }, "", host, host)))
    }
    var edited by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf(false) }
    val focus = remember { FocusRequester() }

    // Every detected link, probed a few at a time.
    val probed = remember { mutableStateMapOf<String, List<VideoOption>>() }
    LaunchedEffect(snapshot.size) {
        coroutineScope {
            val gate = Semaphore(4)
            snapshot.forEach { v ->
                if (!probed.containsKey(v.url)) launch {
                    probed[v.url] = gate.withPermit { VideoProbe.probe(v, userAgent, pageUrl) }
                }
            }
        }
    }
    LaunchedEffect(Unit) {
        val page = PageMetadata.read(webView)
        if (page != null && !edited) PageMetadata.buildName(page).takeIf { it.isNotBlank() }?.let { name = it }
    }
    LaunchedEffect(editing) { if (editing) focus.requestFocus() }

    // Full videos only; if the page has nothing but short clips, show those instead of nothing.
    val all = snapshot.flatMap { probed[it.url].orEmpty() }.filter { it.usable }
    val full = all.filterNot { it.isSmall }
    val hiddenPreviews = if (full.isNotEmpty()) all.size - full.size else 0
    val options = (if (full.isNotEmpty()) full else all)
        .distinctBy { if (it.height == 0 && it.sizeBytes == null) it.url else "${it.isHls}-${it.height}-${it.sizeBytes}" }
        .sortedWith(compareByDescending<VideoOption> { it.height }.thenBy { it.isHls }.thenByDescending { it.sizeBytes ?: 0L })
    val detecting = snapshot.count { !probed.containsKey(it.url) }

    // Pre-selects the resolution used last time until the user picks another.
    var chosenUrl by remember { mutableStateOf<String?>(null) }
    val remembered = remember { ResolutionPrefs.get(ctx) }
    val selected = options.firstOrNull { it.url == chosenUrl } ?: pickPreferred(options, remembered)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Download video") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("File name", style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (editing) {
                        OutlinedTextField(
                            value = name,
                            onValueChange = { name = it; edited = true },
                            suffix = { Text(".mp4") },
                            minLines = 1,
                            maxLines = 5,
                            modifier = Modifier.fillMaxWidth().focusRequester(focus),
                        )
                    } else {
                        // Full name over as many lines as needed; the extension is always .mp4.
                        Text(FileNames.full(name), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                    }
                }

                Text("Available videos", style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)

                options.forEach { o ->
                    Row(
                        Modifier.fillMaxWidth().clickable { chosenUrl = o.url },
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        RadioButton(selected = selected?.url == o.url, onClick = { chosenUrl = o.url })
                        Column(Modifier.padding(start = 4.dp)) {
                            Text(
                                if (o.isHls) "${o.label} · stream" else o.label,
                                style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium,
                            )
                            o.detail?.let {
                                Text(
                                    it, style = MaterialTheme.typography.bodySmall,
                                    color = if (o.hasAudio == false) MaterialTheme.colorScheme.error
                                    else MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    }
                }

                if (detecting > 0) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                        Text("Detecting videos…", modifier = Modifier.padding(start = 12.dp))
                    }
                } else if (options.isEmpty()) {
                    Text("No full video found yet. Start playing the video, then tap the button again.",
                        style = MaterialTheme.typography.bodySmall)
                }
                if (hiddenPreviews > 0) {
                    Text(
                        "$hiddenPreviews short preview clip${if (hiddenPreviews > 1) "s" else ""} hidden",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        },
        // AlertDialog lays these out left to right: Cancel, then the confirm slot (Rename, Download).
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
        confirmButton = {
            Row {
                TextButton(onClick = { editing = !editing }) { Text(if (editing) "Done" else "Rename") }
                TextButton(
                    enabled = selected != null || snapshot.isNotEmpty(),
                    onClick = {
                        val choice = selected ?: snapshot.first().let {
                            VideoOption("Original quality", it.url, it.isHls, 0, null, false, null, null)
                        }
                        ResolutionPrefs.set(ctx, choice.height)      // remembered for next time
                        onConfirm(choice, name)
                    },
                ) { Text("Download") }
            }
        },
    )
}
