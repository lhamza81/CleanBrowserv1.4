package com.example.cleanbrowser.download

import android.webkit.CookieManager
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL

object Http {
    private val REDIRECTS = setOf(301, 302, 303, 307, 308)

    /** Opens a GET, following redirects (also http -> https) and keeping headers, cookies and Range. */
    fun open(
        url: String, ua: String, referer: String,
        rangeStart: Long? = null, rangeEnd: Long? = null, timeout: Int = 15_000,
    ): HttpURLConnection {
        var current = url
        for (hop in 0 until 6) {
            val c = URL(current).openConnection() as HttpURLConnection
            c.instanceFollowRedirects = false
            c.connectTimeout = timeout
            c.readTimeout = timeout
            c.setRequestProperty("User-Agent", ua)
            if (referer.isNotEmpty()) c.setRequestProperty("Referer", referer)
            c.setRequestProperty("Accept-Encoding", "identity")
            runCatching { CookieManager.getInstance().getCookie(current) }.getOrNull()
                ?.let { c.setRequestProperty("Cookie", it) }
            if (rangeStart != null) c.setRequestProperty("Range", "bytes=$rangeStart-" + (rangeEnd?.toString() ?: ""))
            val code = c.responseCode
            if (code in REDIRECTS) {
                val loc = c.getHeaderField("Location")
                c.disconnect()
                if (loc.isNullOrBlank()) throw IOException("Bad redirect")
                current = URI(current).resolve(loc).toString()
                continue
            }
            return c
        }
        throw IOException("Too many redirects")
    }

    fun text(url: String, ua: String, referer: String): String {
        val c = open(url, ua, referer, timeout = 10_000)
        try {
            if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().readText()
        } finally {
            c.disconnect()
        }
    }
}
