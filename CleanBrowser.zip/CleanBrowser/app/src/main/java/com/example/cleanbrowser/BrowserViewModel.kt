package com.example.cleanbrowser

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.example.cleanbrowser.browser.TabManager
import com.example.cleanbrowser.browser.TabStore

class BrowserViewModel(app: Application) : AndroidViewModel(app) {
    val tabManager = TabManager(app).also { m ->
        val saved = TabStore.load(app)
        if (saved != null) m.restore(saved) else m.newTab()
    }

    override fun onCleared() {
        tabManager.destroyAll()
    }
}
