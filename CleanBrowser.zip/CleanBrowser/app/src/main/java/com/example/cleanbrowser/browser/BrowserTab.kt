package com.example.cleanbrowser.browser

import android.graphics.Bitmap
import android.os.Bundle
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

data class DetectedVideo(val url: String, val isHls: Boolean = false)

/** UI-observable state for one tab. The WebView itself lives in [TabManager]. */
class BrowserTab(val id: Int, initialUrl: String) {
    var url by mutableStateOf(initialUrl)
    var title by mutableStateOf("New tab")
    var favicon by mutableStateOf<Bitmap?>(null)
    var progress by mutableIntStateOf(0)
    var canGoBack by mutableStateOf(false)
    var canGoForward by mutableStateOf(false)
    val videos = mutableStateListOf<DetectedVideo>()

    /** Back/forward list + scroll, stored when the WebView is freed to save memory. */
    var savedState: Bundle? = null

    /** Created for window.open()/target=_blank: its WebView must start unused. */
    var isPopup = false

    /** Bumped on every page load so late scans of an old page are ignored. */
    var pageId = 0

    /** Same video (host + path) is kept once, with its newest link because tokens expire. */
    fun addVideo(v: DetectedVideo) {
        val key = VideoDetector.key(v.url)
        val i = videos.indexOfFirst { VideoDetector.key(it.url) == key }
        when {
            i >= 0 -> if (videos[i].url != v.url) videos[i] = v
            videos.size < 50 -> videos.add(v)
        }
    }
}
