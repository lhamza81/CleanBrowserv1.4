package com.example.cleanbrowser.browser

import android.net.Uri

object VideoDetector {
    private const val NONE = 0
    private const val MP4 = 1
    private const val HLS = 2

    private fun kind(path: String?): Int {
        val p = path?.lowercase() ?: return NONE
        return when {
            p.endsWith(".mp4") -> MP4
            p.endsWith(".m3u8") -> HLS
            else -> NONE
        }
    }

    /** Detects direct .mp4 files and .m3u8 streams, also when the link is wrapped in a query parameter. */
    fun classify(url: String): DetectedVideo? = runCatching {
        val uri = Uri.parse(url)
        val scheme = uri.scheme?.lowercase()
        if (scheme != "http" && scheme != "https") return@runCatching null
        when (kind(uri.path)) {
            MP4 -> return@runCatching DetectedVideo(url, isHls = false)
            HLS -> return@runCatching DetectedVideo(url, isHls = true)
        }
        // ...?src=https://cdn.example.com/video.mp4
        for (name in uri.queryParameterNames) {
            val v = uri.getQueryParameter(name) ?: continue
            if (!v.startsWith("http://") && !v.startsWith("https://")) continue
            when (kind(Uri.parse(v).path)) {
                MP4 -> return@runCatching DetectedVideo(v, isHls = false)
                HLS -> return@runCatching DetectedVideo(v, isHls = true)
            }
        }
        null
    }.getOrNull()

    /** Same video served with different tokens = same key (host + path). */
    fun key(url: String): String {
        val u = Uri.parse(url)
        return ((u.host ?: "") + (u.path ?: "")).lowercase()
    }
}
