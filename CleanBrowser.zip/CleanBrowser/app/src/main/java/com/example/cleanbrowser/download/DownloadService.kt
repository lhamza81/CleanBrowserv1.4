package com.example.cleanbrowser.download

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import androidx.core.content.ContextCompat
import com.example.cleanbrowser.browser.Fmt
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/** Keeps the process alive and shows one notification while any download is running or waiting. */
class DownloadService : Service() {

    companion object {
        private const val NOTIF_ID = 4101
        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, DownloadService::class.java))
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var loop: Job? = null
    private var lastStartId = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        lastStartId = startId
        DownloadEngine.ensureChannel(this)
        startForeground(NOTIF_ID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        if (loop?.isActive != true) {
            loop = scope.launch {
                while (isActive) {
                    val busy = DownloadStore.items.value.any { it.state == DlState.DOWNLOADING || it.state == DlState.QUEUED }
                    if (!busy) break
                    getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification())
                    delay(1000)
                }
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf(lastStartId)
            }
        }
        return START_NOT_STICKY
    }

    private fun buildNotification(): Notification {
        val all = DownloadStore.items.value
        val running = all.filter { it.state == DlState.DOWNLOADING }
        val waiting = all.count { it.state == DlState.QUEUED }
        val known = running.filter { it.total > 0 }
        val total = known.sumOf { it.total }
        val pct = if (total > 0) (known.sumOf { it.downloaded } * 100 / total).toInt() else 0
        val speed = running.sumOf { it.speedBps }

        val title = if (running.size == 1) "Downloading 1 file" else "Downloading ${running.size} files"
        val text = listOfNotNull(
            if (waiting > 0) "$waiting waiting" else null,
            if (speed > 0) Fmt.rate(speed) else null,
        ).joinToString(" · ")

        val open = packageManager.getLaunchIntentForPackage(packageName)?.let {
            PendingIntent.getActivity(this, 0, it, PendingIntent.FLAG_IMMUTABLE)
        }
        return Notification.Builder(this, DownloadEngine.CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setProgress(100, pct, total <= 0)
            .build()
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
