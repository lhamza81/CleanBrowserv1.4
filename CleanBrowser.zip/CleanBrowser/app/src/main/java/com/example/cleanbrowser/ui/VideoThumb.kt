package com.example.cleanbrowser.ui

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.produceState
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class MediaInfo(val frame: Bitmap?, val durationSec: Double?, val sizeBytes: Long?, val hasAudio: Boolean?)

/** Reads a preview frame, the length and the size of a saved video. */
suspend fun loadMediaInfo(ctx: Context, uri: Uri): MediaInfo = withContext(Dispatchers.IO) {
    var frame: Bitmap? = null
    var seconds: Double? = null
    var hasAudio: Boolean? = null
    runCatching {
        MediaMetadataRetriever().use { r ->
            r.setDataSource(ctx, uri)
            hasAudio = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO) == "yes"
            seconds = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull()?.takeIf { it > 0 }?.let { it / 1000.0 }
            val f = r.getFrameAtTime(1_000_000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) ?: r.getFrameAtTime(0)
            frame = f?.let { Bitmap.createScaledBitmap(it, 280, (it.height * 280f / it.width).toInt().coerceAtLeast(1), true) }
        }
    }
    val size = runCatching {
        ctx.contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length }?.takeIf { it > 0 }
    }.getOrNull()
    MediaInfo(frame, seconds, size, hasAudio)
}

@Composable
fun rememberMediaInfo(uri: Uri?): State<MediaInfo?> {
    val ctx = LocalContext.current
    return produceState<MediaInfo?>(null, uri) { value = uri?.let { loadMediaInfo(ctx, it) } }
}
