package com.example.cleanbrowser.download

import android.content.Context
import com.example.cleanbrowser.browser.VideoOption

object Downloader {

    /**
     * Starts the download at once. At most 3 run together; further ones wait in the queue and start
     * by themselves. @return true if it started right away, false if it is queued.
     */
    fun enqueue(ctx: Context, option: VideoOption, pageUrl: String, userAgent: String, rawName: String): Boolean =
        DownloadEngine.enqueue(ctx, option, pageUrl, userAgent, rawName)

    fun retry(id: String) = DownloadEngine.retry(id)

    /** Removes the entry and deletes the file (partial or complete). */
    fun remove(ctx: Context, item: DownloadItem) = DownloadEngine.remove(ctx, item)
}
