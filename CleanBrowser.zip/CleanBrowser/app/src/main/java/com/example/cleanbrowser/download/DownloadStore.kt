package com.example.cleanbrowser.download

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import org.json.JSONArray
import org.json.JSONObject

enum class DlState { QUEUED, DOWNLOADING, COMPLETED, FAILED }

data class DownloadItem(
    val id: String,
    val url: String,            // MP4 link, or the chosen HLS (.m3u8) playlist
    val pageUrl: String,
    val userAgent: String,
    val name: String,           // base name, no extension
    val state: DlState,
    val uri: String?,           // MediaStore uri of the file
    val downloaded: Long,
    val total: Long,            // -1 if unknown
    val error: String?,
    val createdAt: Long,
    val isHls: Boolean = false,
    val audioUrl: String? = null,   // separate HLS audio playlist, merged into the MP4
    val speedBps: Long = 0L,        // live download rate (not saved)
    val note: String? = null,       // e.g. "Converting to MP4…" (not saved)
)

object DownloadStore {
    private const val PREFS = "downloads"
    private const val KEY = "json"

    private var prefs: SharedPreferences? = null
    private val _items = MutableStateFlow<List<DownloadItem>>(emptyList())
    val items: StateFlow<List<DownloadItem>> = _items.asStateFlow()

    /** Emits the file name each time a download finishes (drives the bottom pop-up). */
    val completed = MutableSharedFlow<String>(extraBufferCapacity = 8)

    @Synchronized
    fun init(ctx: Context) {
        if (prefs != null) return
        val p = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs = p
        // Anything that was running when the app died goes back in the queue and restarts.
        _items.value = load(p).map { if (it.state == DlState.DOWNLOADING) it.copy(state = DlState.QUEUED) else it }
        save()
    }

    fun get(id: String): DownloadItem? = _items.value.firstOrNull { it.id == id }

    fun add(item: DownloadItem) { _items.update { listOf(item) + it }; save() }

    /** [persist] is false for frequent progress ticks. */
    fun change(id: String, persist: Boolean = true, f: (DownloadItem) -> DownloadItem) {
        _items.update { list -> list.map { if (it.id == id) f(it) else it } }
        if (persist) save()
    }

    fun remove(id: String) { _items.update { list -> list.filterNot { it.id == id } }; save() }

    private fun save() {
        val arr = JSONArray()
        _items.value.forEach {
            arr.put(JSONObject()
                .put("id", it.id).put("url", it.url).put("page", it.pageUrl).put("ua", it.userAgent)
                .put("name", it.name).put("state", it.state.name).put("uri", it.uri ?: JSONObject.NULL)
                .put("done", it.downloaded).put("total", it.total)
                .put("error", it.error ?: JSONObject.NULL).put("at", it.createdAt)
                .put("hls", it.isHls).put("audio", it.audioUrl ?: JSONObject.NULL))
        }
        prefs?.edit()?.putString(KEY, arr.toString())?.apply()
    }

    private fun load(p: SharedPreferences): List<DownloadItem> = runCatching {
        val arr = JSONArray(p.getString(KEY, "[]"))
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            DownloadItem(
                id = o.getString("id"), url = o.getString("url"), pageUrl = o.optString("page"),
                userAgent = o.optString("ua"), name = o.getString("name"),
                state = runCatching { DlState.valueOf(o.getString("state")) }.getOrDefault(DlState.QUEUED),
                uri = if (o.isNull("uri")) null else o.getString("uri"),
                downloaded = o.optLong("done"), total = o.optLong("total", -1L),
                error = if (o.isNull("error")) null else o.getString("error"),
                createdAt = o.optLong("at"),
                isHls = o.optBoolean("hls", false),
                audioUrl = if (o.isNull("audio")) null else o.optString("audio").ifEmpty { null },
            )
        }
    }.getOrDefault(emptyList())
}
